#!/bin/sh

ant $@